Eye Care App for Windows

1. Extract the entire EyeCareApp folder from this ZIP.
2. Double-click EyeCareApp.exe.
3. Tracking starts automatically. Use the tray menu to open Settings or choose Exit.

Your settings are stored in %APPDATA%\EyeCareApp and remain available after replacing the application folder.
