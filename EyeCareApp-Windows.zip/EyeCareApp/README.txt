Eye Care App for Windows

1. Extract the entire EyeCareApp folder from this ZIP.
2. Double-click EyeCareApp.exe.
3. Open the tray icon menu and choose Start to begin tracking.

Use the tray menu's Settings option to change the schedule. Choose Exit to close the app.
Your settings are stored in %APPDATA%\EyeCareApp and remain available after replacing the application folder.
